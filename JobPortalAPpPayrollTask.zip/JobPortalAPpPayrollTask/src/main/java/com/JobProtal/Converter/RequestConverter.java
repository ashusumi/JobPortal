package com.JobProtal.Converter;

import static com.JobProtal.JwtModel.Constants.HEADER_STRING;
import static com.JobProtal.JwtModel.Constants.TOKEN_PREFIX;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.JobProtal.Entity.User;
import com.JobProtal.Repository.UserRepository;
import com.JobProtal.Security.TokenProvider;

@Service
public class RequestConverter {

	@Autowired
	private UserRepository repository;

	@Autowired
	private TokenProvider provider;

	public String getUserName(HttpServletRequest request) {
		String header = request.getHeader(HEADER_STRING);
		String authToken = null;
		String email = null;
		if (header != null && header.startsWith(TOKEN_PREFIX)) {
			authToken = header.replace(TOKEN_PREFIX, "");
			try {
				email = provider.getUsernameFromToken(authToken);
			} catch (IllegalArgumentException e) {
				throw new IllegalArgumentException("an error occured getting username" + e);
			}

		}

		return email;
	}

	// get UserName from email
	public String userName(String email) {
		User user = repository.findByemail(email);
		String userName = user.getUsername();
		return userName;
	}

}
