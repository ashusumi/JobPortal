package com.JobProtal.Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import com.JobProtal.Dto.RegisteredDto;
import com.JobProtal.Dto.UserDto;
import com.JobProtal.Dto.pageDto;

public interface UserService {

	public pageDto<UserDto> getAllUser(int pageNo, int pageSize);

	public String deleteId(Long id);

	String addUser(UserDto user);

	String upadteUser(Long id, UserDto dto);

	public List<RegisteredDto> getRegisteredUser();

	public String updateCandidate(HttpServletRequest request, UserDto dto);

	public void updatePassword(String password, Long userId);
}
