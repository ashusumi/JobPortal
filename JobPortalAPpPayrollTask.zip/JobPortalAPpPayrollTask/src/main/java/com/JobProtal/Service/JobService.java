package com.JobProtal.Service;

import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.data.domain.jaxb.SpringDataJaxb.PageDto;

import com.JobProtal.Dto.JobDto;
import com.JobProtal.Dto.candidateJobDto;
import com.JobProtal.Dto.pageDto;

public interface JobService {

	public List<JobDto> getAllJobs(HttpServletRequest httpServletRequest);

	public String addJobs(JobDto jobs, HttpServletRequest httpServletRequest);

	public String updateJob(JobDto jobs, Long id);

	public String deleteJobs(Long id);

	public String applyJob(HttpServletRequest request, Long Jobid);

	public pageDto<candidateJobDto> getJobForCandidate(int pageNo, int pageSize);
}
