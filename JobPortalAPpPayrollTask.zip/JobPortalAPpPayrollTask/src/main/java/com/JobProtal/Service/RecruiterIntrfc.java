package com.JobProtal.Service;

//getting applied users for specific recruiters job
public interface RecruiterIntrfc {
	public Long getId();

	public String getEmail();

	public String getFirst_Name();

	public String getLast_Name();

	public Long getJob_id();

	public String getJob_Name();

	public String getJob_Description();

	public String getCompany_Name();

}
