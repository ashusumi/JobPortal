package com.JobProtal.ServiceImpl;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.JobProtal.Converter.RequestConverter;
import com.JobProtal.Dto.CandidateDto;
import com.JobProtal.Dto.JobDto;
import com.JobProtal.Dto.candidateJobDto;
import com.JobProtal.Dto.pageDto;
import com.JobProtal.Entity.Job;
import com.JobProtal.Entity.User;
import com.JobProtal.Repository.JobRepository;
import com.JobProtal.Repository.UserRepository;
import com.JobProtal.Service.JobService;
import com.JobProtal.Service.RecruiterIntrfc;

@Service
public class IJob implements JobService {

	@Autowired
	private JobRepository repo;

	@Autowired
	private UserRepository repository;

	@Autowired
	private MailService mailService;

	@Autowired
	private RequestConverter converter;

	// Recruiter can see

	@Override
	public List<JobDto> getAllJobs(HttpServletRequest request) {
		String requirterEmail = converter.getUserName(request);
		String requirterName = converter.userName(requirterEmail);
		List<Job> jobs = repo.findBycreatedBy(requirterName);

		List<JobDto> dto = new ArrayList<>();
		for (int i = 0; i < jobs.size(); i++) {
			JobDto dto1 = new JobDto();
			dto1.setId(jobs.get(i).getId());
			dto1.setJobName(jobs.get(i).getJobName());
			dto1.setEmail(jobs.get(i).getEmail());
			dto1.setJobDescription(jobs.get(i).getJobDescription());
			dto1.setCompanyName(jobs.get(i).getCompanyName());
			dto1.setLocation(jobs.get(i).getLocation());
			dto1.setCreatedBy(jobs.get(i).getCreatedBy());
			dto1.setCreatedOn(jobs.get(i).getCreatedOn());

			dto.add(dto1);
		}

		return dto;
	}

	public pageDto<JobDto> getPagingJob(int pageNo, int pageSize) {
		Pageable pageable = PageRequest.of(pageNo, pageSize, Sort.by("created_on").descending());
		Page<Job> page = repo.findAll(pageable);

		List<JobDto> jobs = page.getContent().stream()
				.map(pg -> new JobDto(pg.getId(), pg.getJobName(), pg.getJobDescription(), pg.getCompanyName(),
						pg.getLocation(), pg.getEmail(), pg.getCreatedOn(), pg.getCreatedBy()))
				.collect(Collectors.toList());

		return new pageDto<>(pageNo, pageSize, page.getTotalPages(), jobs);

	}

	@Override
	public String addJobs(JobDto jobs, HttpServletRequest request) {
		String jobCreaterEmail = converter.getUserName(request);
		String userName = converter.userName(jobCreaterEmail);
		Job job = new Job();

		job.setJobName(jobs.getJobName());
		job.setJobDescription(jobs.getJobDescription());
		job.setCompanyName(jobs.getCompanyName());
		job.setEmail(jobs.getEmail());
		job.setLocation(jobs.getLocation());
		job.setActive(true);
		job.setCreatedBy(userName);
		repo.save(job);
		return "job added successfully!";
	}

	@Override
	public String updateJob(JobDto jobs, Long id) {
		Job job = repo.findById(id).orElse(null);
		job.setJobName(jobs.getJobName());
		job.setJobDescription(jobs.getJobDescription());
		job.setCompanyName(jobs.getCompanyName());
		job.setEmail(jobs.getEmail());
		job.setLocation(jobs.getLocation());
		job.setActive(true);
		repo.save(job);

		return "job updated successfully!";
	}

	@Override
	public String deleteJobs(Long id) {
		Job job = repo.findById(id).orElse(null);
		repo.delete(job);
		return "job deleted";
	}

	public Page<CandidateDto> getJobForCandidate(HttpServletRequest request, int pageNo, int pageSize) {

		String email = converter.getUserName(request);

		User user = repository.findByEmail(email).get();

		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, Sort.by("id").descending());

		Set<Job> jobs = user.getJobs();
		List<Job> newJob = new ArrayList<>(jobs);
		List<CandidateDto> cad = new ArrayList<>();
		for (int i = 0; i < newJob.size(); i++) {
			CandidateDto candidateDto = new CandidateDto();
			candidateDto.setUsername(user.getUsername());
			candidateDto.setEmail(email);
			candidateDto.setJobid(newJob.get(i).getId());
			candidateDto.setJobName(newJob.get(i).getJobName());
			candidateDto.setCompanyName(newJob.get(i).getCompanyName());
			candidateDto.setCompanyEmail(newJob.get(i).getEmail());
			candidateDto.setJobDescription(newJob.get(i).getJobDescription());
			cad.add(candidateDto);
		}

		Page<CandidateDto> page = new PageImpl<>(cad, pageable, cad.size());
		return page;

	}

	// candidate can see
	@Override
	public pageDto<candidateJobDto> getJobForCandidate(int pageNo, int pageSize) {
		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, Sort.by("id").descending());

		Page<Job> page = repo.findAll(pageable);

		List<candidateJobDto> job = page
				.getContent().stream().map(pg -> new candidateJobDto(pg.getId(), pg.getJobName(),
						pg.getJobDescription(), pg.getCompanyName(), pg.getLocation(), pg.getEmail()))
				.collect(Collectors.toList());

		return new pageDto<>(pageNo, pageSize, page.getTotalPages(), job);
	}

	// for recruiter to see candidate applied to specific jobs
	public Page<RecruiterIntrfc> getA(HttpServletRequest request, int pageNo, int pageSize) {
		String createdBY = converter.getUserName(request);
		String name = converter.userName(createdBY);

		List<RecruiterIntrfc> newRec = new ArrayList<>();
		List<Long> id = repo.getIdOfRecruiter(name);
		for (int i = 0; i < id.size(); i++) {
			List<RecruiterIntrfc> user = repository.findUserByJob(id.get(i));
			newRec.addAll(user);
		}

		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, Sort.by("id").descending());
		Page<RecruiterIntrfc> page = new PageImpl<>(newRec, pageable, newRec.size());

		return page;

	}

	@Override
	public String applyJob(HttpServletRequest request, Long Jobid) {
		String email = converter.getUserName(request);

		User user = repository.findByEmail(email).orElse(null);
		String username = user.getUsername();
		Job job = repo.findById(Jobid).orElse(null);

		Set<Job> userJob = user.getJobs();
		userJob.add(job);
		user.setJobs(userJob);
		repository.save(user);

		// send mail to recruiter
		String recruiterEmal = job.getEmail();
		mailService.sendMessage(recruiterEmal, "Job Applied", username + " has applied to job with job id" + Jobid);

		// send mail to candidate
		mailService.sendMessage(email, "Job Appied",
				username + " You have successfully applid for the job with job id" + Jobid);
		return "job applied";
	}

}