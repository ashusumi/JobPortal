package com.JobProtal.ServiceImpl;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

import javax.servlet.http.HttpServletRequest;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.JobProtal.Converter.RequestConverter;
import com.JobProtal.Dto.RegisteredDto;
import com.JobProtal.Dto.UserDto;
import com.JobProtal.Dto.pageDto;
import com.JobProtal.Entity.Role;
import com.JobProtal.Entity.User;
import com.JobProtal.Repository.RoleRepository;
import com.JobProtal.Repository.UserRepository;
import com.JobProtal.Service.UserService;

@Service
public class IUser implements UserService {

	@Autowired
	private UserRepository repo;

	@Autowired
	private RoleRepository rrepo;

	@Autowired
	private PasswordEncoder encoder;

	@Autowired
	private PasswordValidator passwordValidator;

	@Autowired
	private RequestConverter converter;

	Logger logger = LoggerFactory.getLogger(IUser.class);

	// can see the users
	@Override
	public pageDto<UserDto> getAllUser(int pageNo, int pageSize) {

		Pageable pageable = PageRequest.of(pageNo - 1, pageSize, Sort.by("id").descending());
		Page<User> page = repo.findAll(pageable);
		List<UserDto> dtos = page
				.getContent().stream().map(pg -> new UserDto(pg, pg.getId(), pg.getUsername(), pg.getEmail(),
						pg.getFirstName(), pg.getLastName(), pg.getPassword(), pg.getRoles()))
				.collect(Collectors.toList());
		return new pageDto<>(pageNo, pageSize, page.getTotalPages(), dtos);
	}

	// can add the users
	@Override
	public String addUser(UserDto user) {

		User newUser = new User();
		long id = 1;
		Set<Role> Drole = new HashSet<>();
		Role roleD = rrepo.findById(id).orElse(null);
		Drole.add(roleD);
		List<User> users = new ArrayList<>();
		newUser.setUsername(user.getUsername());
		newUser.setEmail(user.getEmail());
		newUser.setFirstName(user.getFirstName());
		newUser.setLastName(user.getLastName());
		newUser.setActive(true);
		String encp = user.getPassword();
		if (passwordValidator.validate(encp)) {
			newUser.setPassword(encoder.encode(encp));
		} else {
			throw new IllegalArgumentException("password should satisfy the condition ");
		}
		newUser.setRoles(Drole);
		users.add(newUser);
		repo.saveAll(users);
		return "User added";

	}

	// can update the users by admin only
	@Override
	public String upadteUser(Long id, UserDto dto) {
		User user = repo.findById(id).orElse(null);
		if (user != null) {
			user.setFirstName(dto.getFirstName());
			user.setLastName(dto.getLastName());
			user.setUsername(dto.getUsername());
			user.setEmail(dto.getEmail());
			repo.save(user);
		} else {
			throw new IllegalArgumentException("no user with given id");
		}

		return "user updated";

	}

	// can update the candidate or recruiter
	@Override
	public String updateCandidate(HttpServletRequest request, UserDto dto) throws IllegalArgumentException {
		String email = converter.getUserName(request);
		User user = repo.findByemail(email);
		System.out.println(user);
		if (user != null) {

			user.setFirstName(dto.getFirstName());
			user.setLastName(dto.getLastName());
			user.setUsername(dto.getUsername());
			user.setEmail(dto.getEmail());
			repo.save(user);
		} else {
			throw new IllegalArgumentException("no User with username");
		}
		return "User updated";
	}

	// can delete the user by admin only
	@Override
	public String deleteId(Long id) {
		User user = repo.findById(id).orElse(null);
		if (user != null) {
			repo.delete(user);
		} else {
			throw new IllegalArgumentException("no user with given id :" + id);
		}
		return "deleted";
	}

	// can assign the role by admin only
	public void assignUserRole(Long userId, Long RoleId) throws Exception {
		User user = repo.findById(userId).orElse(null);
		Role role = rrepo.findById(RoleId).orElse(null);

		if (role != null) {
			Set<Role> userRole = user.getRoles();
			userRole.add(role);
			user.setRoles(userRole);
			repo.save(user);
		} else {
			throw new IllegalArgumentException("no role with given role id " + RoleId);
		}

	}

	@Override
	public List<RegisteredDto> getRegisteredUser() {
		List<User> user = repo.findAll();
		List<RegisteredDto> newDto = new ArrayList<>();
		for (int i = 0; i < user.size(); i++) {
			RegisteredDto reg = new RegisteredDto();
			reg.setEmail(user.get(i).getEmail());
			reg.setFirstName(user.get(i).getFirstName());
			reg.setLastName(user.get(i).getLastName());
			reg.setUsername(user.get(i).getUsername());
			newDto.add(reg);
		}
		return newDto;
	}

	// for passwordupdate
	@Override
	public void updatePassword(String password, Long userId) {
		repo.updatePassword(password, userId);

	}
}
