package com.JobProtal.ServiceImpl;

import java.util.regex.Pattern;

import org.springframework.stereotype.Service;

@Service
public class PasswordValidator {

	private static final String PASSWORD_PATTERN = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[@#$%^&+=])(?=\\S+$).{8,}$";
	private static final Pattern pattern = Pattern.compile(PASSWORD_PATTERN);

	public boolean validate(final String password) {
		return pattern.matcher(password).matches();
	}
}
