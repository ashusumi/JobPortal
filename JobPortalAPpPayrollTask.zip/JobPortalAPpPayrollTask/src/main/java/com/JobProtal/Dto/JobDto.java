package com.JobProtal.Dto;

import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class JobDto {

	private Long id;
	@NotNull(message = "jobName should not be null *jobName required")
	@NotBlank(message = "jobName should not be blank or null *jobName required")
	@NotEmpty(message = "jobName should not be empty or blank or null *jobName required")
	private String jobName;
	@NotNull(message = "jobDescription should not be  null *jobDescription required\"")
	@NotBlank(message = "jobDescription should not be blank or null *jobDescription required\"")
	@NotEmpty(message = "jobDescription should not be empty or blank or null *jobDescription required")
	private String jobDescription;
	@NotNull(message = "comapnyNam should not be null *companyName required")
	@NotBlank(message = "comapnyNam should not be blank or null *companyName required")
	@NotEmpty(message = "comapnyNam should not be empty or blank or null *companyName required")
	private String companyName;
	private boolean isActive = true;
	@NotNull(message = "location sholud not be null *location required")
	@NotBlank(message = "location sholud not be blank or null *location required")
	@NotEmpty(message = "location sholud not be empty or blank or null *location required")
	private String location;
	@NotNull(message = "email should not be null *email erquired")
	@NotBlank(message = "email should not be blank or null *email erquired")
	@NotEmpty(message = "email should not be empty or blank or null *email erquired")
	private String email;

	private Date createdOn;

	private String createdBy;

	// private User user;

	public JobDto(Long id, String jobName, String jobDescription, String companyName, String location, String email,
			Date createdOn, String createdBy) {
		super();
		this.id = id;
		this.jobName = jobName;
		this.jobDescription = jobDescription;
		this.companyName = companyName;
		this.location = location;
		this.email = email;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
	}

	public JobDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

}
