package com.JobProtal.Dto;

import java.io.Serializable;

import javax.validation.constraints.NotNull;

public class candidateJobDto implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private Long id;
	@NotNull(message = "jobname required")
	private String jobName;
	@NotNull(message = "jobdescription required")
	private String jobDescription;
	@NotNull(message = "companyname required")
	private String companyName;
	@NotNull(message = "location required")
	private String location;
	@NotNull(message = "email required")
	private String email;

	public candidateJobDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public candidateJobDto(Long id, String jobName, String jobDescription, String companyName, String location,
			String email) {
		super();
		this.id = id;
		this.jobName = jobName;
		this.jobDescription = jobDescription;
		this.companyName = companyName;
		this.location = location;
		this.email = email;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

}
