package com.JobProtal.Dto;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;

import com.JobProtal.Constraints.FieldMatch;

@FieldMatch(first = "password", second = "confirmPassword")
public class PasswordResetDto {

	@NotBlank(message = "password should not be blank* password required")
	@NotEmpty(message = "password should not be empty or blank* password required")
	private String password;
	@NotEmpty(message = "confirm password should not be blank* password required")
	@NotEmpty(message = "confirm password should not be empty blank* password required")
	private String confirmPassword;

	@NotBlank(message = "token should be blank *token is mandatory")
	@NotEmpty(message = "token should be empty or blank *token is mandatory")
	private String token;

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getConfirmPassword() {
		return confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getToken() {
		return token;
	}

	public void setToken(String token) {
		this.token = token;
	}

}
