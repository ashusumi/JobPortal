package com.JobProtal.Dto;

import java.util.List;

public class pageDto<T> {

	private int pageNo;
	private int pageSize;
	private int totalPages;
	private List<T> data;

	public pageDto() {
		super();
	}

	public pageDto(int pageNo, int pageSize, int totalPages, List<T> data) {
		super();
		this.pageNo = pageNo;
		this.pageSize = pageSize;
		this.totalPages = totalPages;
		this.data = data;
	}

	public int getPageNo() {
		return pageNo;
	}

	public void setPageNo(int pageNo) {
		this.pageNo = pageNo;
	}

	public int getPageSize() {
		return pageSize;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}

	public int getTotalPages() {
		return totalPages;
	}

	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}

	public List<T> getData() {
		return data;
	}

	public void setData(List<T> data) {
		this.data = data;
	}

}