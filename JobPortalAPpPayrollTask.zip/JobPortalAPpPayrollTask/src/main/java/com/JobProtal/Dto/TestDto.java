package com.JobProtal.Dto;

import javax.validation.constraints.NotNull;

public class TestDto {

	@NotNull
	private String username;

	@NotNull
	private String email;

	@NotNull
	private String jobname;

	@NotNull
	private String jobdescription;

	public TestDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public TestDto(String username, String email, String jobname, String jobdescription) {
		super();
		this.username = username;
		this.email = email;
		this.jobname = jobname;
		this.jobdescription = jobdescription;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJobname() {
		return jobname;
	}

	public void setJobname(String jobname) {
		this.jobname = jobname;
	}

	public String getJobdescription() {
		return jobdescription;
	}

	public void setJobdescription(String jobdescription) {
		this.jobdescription = jobdescription;
	}

}
