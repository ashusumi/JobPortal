package com.JobProtal.Dto;

import java.io.Serializable;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

public class CandidateDto implements Serializable {

	private static final long serialVersionUID = 1L;

	private Long Jobid;

	private String username;

	private String email;

	private String jobName;

	private String jobDescription;

	private String companyName;

	private String companyEmail;

	public CandidateDto() {
		super();
		// TODO Auto-generated constructor stub
	}

	public CandidateDto(Long Jobid, String username, String email, String jobName, String jobDescription,
			String companyName, String companyEmail) {
		super();
		this.Jobid = Jobid;
		this.username = username;
		this.email = email;
		this.jobName = jobName;
		this.jobDescription = jobDescription;
		this.companyName = companyName;
		this.companyEmail = companyEmail;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCompanyEmail() {
		return companyEmail;
	}

	public void setCompanyEmail(String companyEmail) {
		this.companyEmail = companyEmail;
	}

	public Long getJobid() {
		return Jobid;
	}

	public void setJobid(Long jobid) {
		Jobid = jobid;
	}

}
