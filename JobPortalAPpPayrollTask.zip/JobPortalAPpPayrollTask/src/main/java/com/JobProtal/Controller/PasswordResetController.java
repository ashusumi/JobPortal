package com.JobProtal.Controller;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.JobProtal.Dto.PasswordResetDto;
import com.JobProtal.Entity.PasswordResetToken;
import com.JobProtal.Entity.User;
import com.JobProtal.Exception.ResponseHandler;
import com.JobProtal.Repository.PasswordResetTokenRepository;
import com.JobProtal.ServiceImpl.IUser;
import com.JobProtal.ServiceImpl.PasswordValidator;

@RestController
@RequestMapping("/resetPass")
public class PasswordResetController {

	@Autowired
	private IUser iUser;

	@Autowired
	private PasswordResetTokenRepository tokenRepository;

	@Autowired
	private BCryptPasswordEncoder encoder;

	@Autowired
	private PasswordValidator validator;

	@PostMapping
	@Transactional
	public ResponseEntity<?> resetPassword(@Valid @RequestBody PasswordResetDto dto) {
		PasswordResetToken passwordResetToken = tokenRepository.findByToken(dto.getToken());

		if (passwordResetToken != null) {
			User user = passwordResetToken.getUser();

			String password = dto.getPassword();
			if (validator.validate(password)) {
				String updatePassword = encoder.encode(password);

				iUser.updatePassword(updatePassword, user.getId());
			} else {
				throw new IllegalArgumentException("password should be in appropriate format");
			}
			tokenRepository.delete(passwordResetToken);

			return ResponseHandler.getResponseWithoutObj("password reseted successfully!", HttpStatus.OK);
		} else {
			throw new IllegalArgumentException("token dosent match ");
		}
	}
}
