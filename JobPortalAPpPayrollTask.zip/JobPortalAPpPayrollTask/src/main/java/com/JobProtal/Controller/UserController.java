package com.JobProtal.Controller;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.JobProtal.Dto.RegisteredDto;
import com.JobProtal.Dto.UserDto;
import com.JobProtal.Entity.User;
import com.JobProtal.Exception.ResponseHandler;
import com.JobProtal.Repository.UserRepository;
import com.JobProtal.ServiceImpl.IJob;
import com.JobProtal.ServiceImpl.IUser;

@RestController
@Validated
@RequestMapping("/user")
public class UserController {
	@Autowired
	private IUser service;

	@Autowired
	private UserRepository repo;

	@Autowired
	private IJob iJob;

	// admin only to see the users added
	@GetMapping()
	@PreAuthorize("hasAuthority('ALL')")
	public ResponseEntity<?> getAllUser(@RequestParam(defaultValue = "1") int pageNo,
			@RequestParam(defaultValue = "10") int pageSize) {

		return ResponseHandler.getResponse("all users", HttpStatus.OK, service.getAllUser(pageNo, pageSize));
	}

	@PreAuthorize("hasAuthority('ALL')")
	@GetMapping("/admin")
	public List<User> getUser() {
		return repo.findAll();
	}

	// for admin only can add users
	@PostMapping()
	@PreAuthorize("hasAuthority('ALL')")
	public ResponseEntity<?> addUser(@Valid @RequestBody UserDto user) {

		service.addUser(user);
		return ResponseHandler.getResponse("user added successfully!", HttpStatus.OK, null);

	}

	// for admin only to delete the user
	@PreAuthorize("hasAuthority('ALL')")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteUser(@PathVariable Long id) {
		service.deleteId(id);
		return ResponseHandler.getResponseWithoutObj("user deleted successfully!", HttpStatus.OK);
	}

	// can update by admin only
	@PreAuthorize("hasAuthority('ALL') or hasAuthority('READ') or hasAuthority('WRITE')")
	@PutMapping("/{id}")
	public ResponseEntity<?> updateUserByAdmin(@PathVariable Long id, @RequestBody UserDto dto) {
		service.upadteUser(id, dto);
		return ResponseHandler.getResponseWithoutObj("user updated successfully!", HttpStatus.OK);
	}

	// only admiassign role
	@PreAuthorize("hasAuthority('ALL')")
	@PostMapping("/assign")
	public ResponseEntity<?> assign(Long userId, Long roleId) throws Exception {
		service.assignUserRole(userId, roleId);
		return ResponseHandler.getResponseWithoutObj("role assign to user successfully!", HttpStatus.OK);
	}

	// can see registered users
	@PreAuthorize("hasAuthority('ALL')")
	@GetMapping("/registeredUser")
	public ResponseEntity<?> get() {
		List<RegisteredDto> registeredUser = service.getRegisteredUser();
		return ResponseHandler.getResponse("registered users", HttpStatus.OK, registeredUser);
	}

	// only candidate can invoke for applying jobs
	@PostMapping("/apply")
	@PreAuthorize("hasAuthority('READ')")
	public ResponseEntity<?> applyJob(HttpServletRequest email, Long jobId) {

		iJob.applyJob(email, jobId);

		return ResponseHandler.getResponseWithoutObj("job applied successfully!", HttpStatus.OK);
	}

	// for candidate and recruiter for updating
	@PreAuthorize("hasAuthority('READ') or hasAuthority('WRITE')")
	@PutMapping("/update")
	public ResponseEntity<?> updateUser(HttpServletRequest request, @RequestBody UserDto dto) {
		service.updateCandidate(request, dto);
		return ResponseHandler.getResponseWithoutObj("User updated successfully! ", HttpStatus.OK);
	}

}
