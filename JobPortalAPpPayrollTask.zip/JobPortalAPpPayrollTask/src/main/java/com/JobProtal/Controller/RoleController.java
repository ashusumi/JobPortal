package com.JobProtal.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.JobProtal.Dto.RoleDto;
import com.JobProtal.Entity.Role;
import com.JobProtal.Exception.ErrorResponseDto;
import com.JobProtal.Exception.ResponseHandler;
import com.JobProtal.Repository.RoleRepository;
import com.JobProtal.ServiceImpl.IRole;

@RestController
@RequestMapping("/role")
public class RoleController {

	@Autowired
	private IRole Irole;

	@Autowired
	private RoleRepository repo;

	@PreAuthorize("hasAuthority('ALL')")

	@GetMapping()
	public List<RoleDto> getAllRole() {
		return Irole.getAllRole();
	}

	@PreAuthorize("hasAuthority('ALL')")
	@GetMapping("/admin")
	public List<Role> getRole() {
		return repo.findAll();
	}

	@PreAuthorize("hasAuthority('ALL')")

	@PostMapping()
	public ResponseEntity<?> addRole(@RequestBody RoleDto role) {
		try {
			Irole.addRole(role);
			return ResponseHandler.getResponseWithoutObj("role added successfully!", HttpStatus.OK);
		} catch (Exception e) {
			return new ResponseEntity<>(new ErrorResponseDto(e.getMessage(), "role not added"), HttpStatus.BAD_REQUEST);
		}

	}

	@PreAuthorize("hasAuthority('ALL')")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteRole(@PathVariable Long id) {
		Irole.deleteRole(id);
		return ResponseHandler.getResponseWithoutObj("role deleted successfully!", HttpStatus.OK);
	}

	@PreAuthorize("hasAuthority('ALL')")
	@PutMapping("/{id}")
	public ResponseEntity<?> update(@PathVariable Long id, @RequestBody RoleDto role) {
		Irole.updateRole(id, role);
		return ResponseHandler.getResponseWithoutObj("role updated successfully!", HttpStatus.OK);
	}
}
