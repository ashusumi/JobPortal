package com.JobProtal.Controller;

import javax.servlet.http.HttpServletRequest;
import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.JobProtal.Dto.CandidateDto;
import com.JobProtal.Dto.JobDto;
import com.JobProtal.Dto.candidateJobDto;
import com.JobProtal.Dto.pageDto;
import com.JobProtal.Exception.ResponseHandler;
import com.JobProtal.Service.RecruiterIntrfc;
import com.JobProtal.ServiceImpl.IJob;

@RestController
@Validated
@RequestMapping("/job")
public class JobController {

	@Autowired
	private IJob service;

	@GetMapping()
//	@PreAuthorize("hasAuthority('WRITE') or hasAuthority('READ')or hasAuthority('ALL')")
	public ResponseEntity<?> getAllJob(HttpServletRequest req) {
		return ResponseHandler.getResponse("all jobs", HttpStatus.OK, service.getAllJobs(req));
	}

//	@PreAuthorize("hasAuthority('WRITE')or hasAuthority('ALL')")
	@PostMapping("/addJob")
	public ResponseEntity<?> addJob(@Valid @RequestBody JobDto jobs, HttpServletRequest request) {
		service.addJobs(jobs, request);
		return ResponseHandler.getResponseWithoutObj("job added successfully", HttpStatus.OK);
	}

	@PreAuthorize("hasAuthority('WRITE')or hasAuthority('ALL')")
	@PutMapping("/{id}")
	public ResponseEntity<?> editJob(@RequestBody JobDto jobs, @PathVariable Long id) {
		service.updateJob(jobs, id);
		return ResponseHandler.getResponseWithoutObj("job updated successfully!", HttpStatus.OK);
	}

	@PreAuthorize("hasAuthority('WRITE')or hasAuthority('ALL')")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deleteJob(@PathVariable Long id) {
		service.deleteJobs(id);
		return ResponseHandler.getResponseWithoutObj("job deleted successfully!", HttpStatus.OK);
	}

	@PreAuthorize("hasAuthority('READ') or hasAuthority('WRITE') or hasAuthority('ALL')")
	@GetMapping("/candidate")
	public ResponseEntity<?> getalljob(HttpServletRequest request, @RequestParam(defaultValue = "1") int pageNo,
			@RequestParam(defaultValue = "5") int pageSize) {
		Page<CandidateDto> ls = service.getJobForCandidate(request, pageNo, pageSize);
		return ResponseHandler.getResponse("all jobs", HttpStatus.OK, ls);
	}

	@PreAuthorize("hasAuthority('READ')")
	@GetMapping("/candidateJob")
	public ResponseEntity<?> getAllCandiJob(@RequestParam(defaultValue = "1") int pageNo,
			@RequestParam(defaultValue = "5") int pageSize) {
		pageDto<candidateJobDto> pg = service.getJobForCandidate(pageNo, pageSize);
		return ResponseHandler.getResponse("jobs for candidate", HttpStatus.OK, pg);
	}

	@PreAuthorize("hasAuthority('WRITE') or hasAuthority('ALL')")
	@GetMapping("/recJob")
	public ResponseEntity<?> getJobRec(HttpServletRequest httpServletRequest,
			@RequestParam(defaultValue = "1") int pageNo, @RequestParam(defaultValue = "5") int pageSize) {
		Page<RecruiterIntrfc> pg = service.getA(httpServletRequest, pageNo, pageSize);
		return ResponseHandler.getResponse("recruiters job", HttpStatus.OK, pg);

	}

	@PreAuthorize("hasAuthority('WRITE')or hasAuthority('ALL')")
	@GetMapping("/paginatedJob")
	public ResponseEntity<?> getJOb(@RequestParam(defaultValue = "0") int pageNo,
			@RequestParam(defaultValue = "5") int pageSize) {
		pageDto<JobDto> page = service.getPagingJob(pageNo, pageSize);
		return ResponseHandler.getResponse("job with pagination", HttpStatus.OK, page);
	}
}
