package com.JobProtal.Controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.JobProtal.Exception.ResponseHandler;
import com.JobProtal.ServiceImpl.MailService;

@RestController
@RequestMapping("/mail")
public class mailController {

	@Autowired
	private MailService mailService;

	@PostMapping("/send")
	public ResponseEntity<?> sendMail() {
		this.mailService.sendMessage("beherad592@gmail.com", "greetings from nimap", "Here is the token");
		return ResponseHandler.getResponseWithoutObj("mail sent successfully to desired address!", HttpStatus.OK);
	}
}
