package com.JobProtal.Controller;

import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.JobProtal.Entity.PasswordResetToken;
import com.JobProtal.Entity.User;
import com.JobProtal.Exception.ResponseHandler;
import com.JobProtal.Repository.PasswordResetTokenRepository;
import com.JobProtal.Repository.UserRepository;
import com.JobProtal.ServiceImpl.MailService;

@RestController
@RequestMapping("/forgot")
public class PasswordForgotController {

	@Autowired
	private UserRepository repository;

	@Autowired
	private PasswordResetTokenRepository tokenRepository;

	@Autowired
	private MailService mailService;

	@PostMapping()
	public ResponseEntity<?> forgotPassword(String email) throws Exception {

		User user = repository.findByemail(email);
		Long id = user.getId();

		String token2bchk = tokenRepository.getTokenByUserId(id);

		if (token2bchk != null) {

			Long id2Delt = tokenRepository.getIdByTokenName(token2bchk);
			tokenRepository.deleteById(id2Delt);

		}
		PasswordResetToken token = new PasswordResetToken();
		token.setToken(UUID.randomUUID().toString().substring(0, 4));
		token.setUser(user);
		token.setExiryDate(30);
		String testToken = tokenRepository.getTokenByUserId(id);
		System.out.println(testToken);

		mailService.sendMessage(email, "Code is valid only for 10 min",
				" provided code is only for one time\n to reset the password you have to provide the code :"
						+ token.getToken());
		new ResponseHandler();
		return ResponseHandler.getResponseWithoutObj("otp sent to mail", HttpStatus.OK);

	}
}
