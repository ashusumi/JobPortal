package com.JobProtal.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.JobProtal.Dto.PermissionDto;
import com.JobProtal.Exception.ResponseHandler;
import com.JobProtal.ServiceImpl.IPermission;

@RestController
@RequestMapping("/permission")
public class PermissionController {

	@Autowired
	private IPermission permissionS;

	@PostMapping()
	@PreAuthorize("hasAuthority('ALL')")
	public ResponseEntity<?> addPermission(@RequestBody PermissionDto permission) {
		permissionS.addPermission(permission);
		return ResponseHandler.getResponseWithoutObj("permission added successfully!", HttpStatus.OK);
	}

	@PreAuthorize("hasAuthority('ALL')")
	@GetMapping()
	public ResponseEntity<?> getALLPermission() {
		List<PermissionDto> pr = permissionS.getAllPermission();
		return ResponseHandler.getResponse("user permissions", HttpStatus.OK, pr);
	}

	@PreAuthorize("hasAuthority('ALL')")
	@PutMapping("/{id}")
	public ResponseEntity<?> updatePermission(@PathVariable Long id, @RequestBody PermissionDto permission) {

		permissionS.updatePermission(id, permission);
		return ResponseHandler.getResponseWithoutObj("permission updated successfully!", HttpStatus.OK);
	}

	@PreAuthorize("hasAuthority('ALL')")
	@DeleteMapping("/{id}")
	public ResponseEntity<?> deletePermission(@PathVariable Long id) {
		permissionS.deletePermission(id);
		return ResponseHandler.getResponseWithoutObj("permission updated successfully!", HttpStatus.OK);
	}
}
