package com.JobProtal.JwtModel;

public class AuthToken {
	private String tokne;

	public AuthToken() {
		super();
		// TODO Auto-generated constructor stub
	}

	public AuthToken(String tokne) {
		super();
		this.tokne = tokne;
	}

	public String getTokne() {
		return tokne;
	}

}
