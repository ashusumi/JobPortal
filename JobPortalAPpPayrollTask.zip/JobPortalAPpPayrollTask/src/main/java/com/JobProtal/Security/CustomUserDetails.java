package com.JobProtal.Security;

import java.util.Collection;
import java.util.HashSet;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Component;

import com.JobProtal.Entity.Role;
import com.JobProtal.Entity.User;
import com.JobProtal.Repository.UserRepository;

@Component
public class CustomUserDetails implements UserDetailsService {

	@Autowired
	private UserRepository repository;

	@Autowired
	private RedisTemplate<String, Object> redisTemplate;

	@Override
	public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
		User user = repository.findByemail(email);
		System.out.println(user);
		if (user == null) {
			throw new UsernameNotFoundException(email + "not found");
		}

		redisTemplate.opsForValue().set(user.getUsername(), getAuth(user));
		return new org.springframework.security.core.userdetails.User(user.getEmail(), user.getPassword(),
				getAuth(user));
	}

	private Collection<GrantedAuthority> getAuth(User user) {
		Set<GrantedAuthority> ga = new HashSet<>();

		for (Role role : user.getRoles()) {
			// ga.add(new SimpleGrantedAuthority(role.getRole()));

			for (com.JobProtal.Entity.Permission permission : role.getPermissions()) {
				ga.add(new SimpleGrantedAuthority(permission.getPermissionName()));

			}
		}

		System.out.println(ga);

		return ga;
	}

}
