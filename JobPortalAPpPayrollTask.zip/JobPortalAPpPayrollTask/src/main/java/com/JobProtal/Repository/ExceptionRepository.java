package com.JobProtal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.JobProtal.Exception.ExceptionEntity;

public interface ExceptionRepository extends JpaRepository<ExceptionEntity, Long> {

}
