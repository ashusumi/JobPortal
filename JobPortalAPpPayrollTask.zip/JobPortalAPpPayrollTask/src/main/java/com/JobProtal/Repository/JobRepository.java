package com.JobProtal.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import com.JobProtal.Entity.Job;

public interface JobRepository extends JpaRepository<Job, Long> {

	List<Job> findBycreatedBy(String cretadBy);

	@Query(value = "select j.id from Job j where created_by= :createdBy", nativeQuery = true)
	List<Long> getIdOfRecruiter(@Param("createdBy") String createdBy);
}
