package com.JobProtal.Repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.JobProtal.Entity.Job;
import com.JobProtal.Entity.User;
import com.JobProtal.Service.RecruiterIntrfc;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

	Optional<User> findByEmail(String email);

	User findByUsername(String username);

	User findByemail(String email);

	List<User> findByjobs(Job jobs);

	// query for getting applied users to job
	@Query(value = "select u.id,u.first_name,u.last_name,u.email,j.id as job_id,j.job_name,j.job_description ,j.compapy_name as company_name  from users  u \r\n"
			+ "join user_job uj \r\n" + "on u.id =uj.user_id \r\n" + "join  job j  \r\n" + "on uj.job_id =j.id \r\n"
			+ "where j.id = :id", nativeQuery = true)
	List<RecruiterIntrfc> findUserByJob(@Param("id") Long id);

	// update users password (reset password)
	@Modifying
	@Query("update User u set u.password = :password where u.id = :id")
	void updatePassword(@Param("password") String password, @Param("id") Long id);

}
