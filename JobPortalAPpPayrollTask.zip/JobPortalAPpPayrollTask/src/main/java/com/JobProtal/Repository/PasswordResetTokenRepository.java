package com.JobProtal.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.JobProtal.Entity.PasswordResetToken;

import io.lettuce.core.dynamic.annotation.Param;

@Repository
public interface PasswordResetTokenRepository extends JpaRepository<PasswordResetToken, Long> {
	PasswordResetToken findByToken(String token);

	@Query(value = "select token from password_reset_token prt where user_id = :id", nativeQuery = true)
	String getTokenByUserId(@Param("id") Long id);

	@Query(value = "select id from password_reset_token where token= :token1", nativeQuery = true)
	Long getIdByTokenName(@Param("token") String token1);

}
