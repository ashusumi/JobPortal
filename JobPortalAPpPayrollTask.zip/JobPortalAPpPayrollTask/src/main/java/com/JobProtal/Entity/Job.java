package com.JobProtal.Entity;

import java.io.Serializable;
import java.util.Date;
import java.util.Set;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.SQLDelete;
import org.hibernate.annotations.Where;

@Entity
@Table(name = "Job")
@Where(clause = "is_active=true")
@SQLDelete(sql = "UPDATE Job set is_active=false where id=?")
public class Job implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)

	@Column(name = "Id")
	private long id;

	@Column(name = "JobName")

	private String jobName;

	@Column(name = "JobDescription")

	private String jobDescription;
	@Column(name = "CompapyName")

	private String companyName;

	@Column(name = "Location")

	private String location;

	@Column(name = "Email")

	private String email;

	@Column(name = "IsActive")
	private boolean isActive = true;

	@Column(name = "CreatedOn")
	@CreationTimestamp
	private Date createdOn;

	@Column(name = "CreatedBy")
	private String createdBy;

	@ManyToMany(mappedBy = "jobs")
	private Set<User> user;

	public Job(long id, String jobName, String jobDescription, String companyName, String location, String email,
			boolean isActive, Date createdOn, String createdBy, Set<User> user) {
		super();
		this.id = id;
		this.jobName = jobName;
		this.jobDescription = jobDescription;
		this.companyName = companyName;
		this.location = location;
		this.email = email;
		this.isActive = isActive;
		this.createdOn = createdOn;
		this.createdBy = createdBy;
		this.user = user;
	}

	public Job() {
		super();
		// TODO Auto-generated constructor stub
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getJobName() {
		return jobName;
	}

	public void setJobName(String jobName) {
		this.jobName = jobName;
	}

	public String getJobDescription() {
		return jobDescription;
	}

	public void setJobDescription(String jobDescription) {
		this.jobDescription = jobDescription;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public boolean isActive() {
		return isActive;
	}

	public void setActive(boolean isActive) {
		this.isActive = isActive;
	}

	public Date getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(Date createdOn) {
		this.createdOn = createdOn;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

}
