package com.JobProtal.ServiceImpl;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class IUserTest {

	@Test
	void test() {
		fail("Not yet implemented");
	}

}
